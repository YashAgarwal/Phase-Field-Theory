#!/bin/bash
echo 'Ploting the data......'
gnuplot --persist <plotFig2.gp
