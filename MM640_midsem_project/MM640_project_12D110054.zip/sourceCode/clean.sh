echo "Deleting the Current data"

cd ./mainData
./clean.sh

cd ../Fig6
./clean.sh

cd ../Fig5
./clean.sh

cd ../Fig4
./clean.sh

