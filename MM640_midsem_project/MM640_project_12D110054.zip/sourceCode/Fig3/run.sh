#!/bin/bash
echo 'Ploting the data......'
gnuplot --persist <plotFig3.gp
