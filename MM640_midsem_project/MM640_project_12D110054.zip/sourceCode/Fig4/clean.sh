rm -f analysis*.dat
rm -f a.out