rm -f R*.dat
rm -f a.out