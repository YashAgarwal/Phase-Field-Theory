rm -f plotAnimation*.gp
rm -f final*.dat
rm -f -r output*
rm -f a.out