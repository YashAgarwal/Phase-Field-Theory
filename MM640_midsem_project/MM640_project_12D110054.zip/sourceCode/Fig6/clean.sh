rm -f SS*.dat
rm -f fD*.dat
rm -f a.out

cd ./data/withGb

./clean.sh

cd ../withoutGb

./clean.sh

