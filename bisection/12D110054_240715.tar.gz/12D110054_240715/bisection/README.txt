The format of the input file is

a b
Tol
Nmax

The program calculates the roots of the function mentioned in the code as the function f() using the bisection algorithm between the values a and b, where a is lesser than b, with in an error interval of Tol and runs for upto Nmax cycles.  